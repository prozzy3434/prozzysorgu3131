//here the event starts
module.exports = (client, id, replayedEvents) => {
}
